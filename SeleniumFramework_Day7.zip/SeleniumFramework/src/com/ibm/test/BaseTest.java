package com.ibm.test;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ibm.pages.Login;

import com.ibm.pages.*;
import com.ibm.utilities.ExcelUtil;
import com.ibm.utilities.PropertiesFileHandler;
import org.testng.Assert;


//jars would be in the link
// https://drive.google.com/open?id=1Oa7AzFN8nQapvatjRToU_bwDgpf18QKI
public class BaseTest extends WebDriverLaunch
{
	@Test
	public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		
		String url = data.get("url");
		String userName = data.get("user");
		String password = data.get("password");
		driver.get(url);
		
		Login loginele = new Login(driver, wait);
		loginele.enterEmailAddress(userName);
		loginele.enterPassword(password);
		loginele.clickOnLogin();
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));

		AdminPage admin = new AdminPage(driver, wait);
		admin.clickonCatalogetab();
		admin.clickonProductTab();
		admin.clickonProductAddNew();
		
		driver.findElement(By.xpath("//input[@id='pro_name']")).sendKeys("New Prod Req");
		driver.findElement(By.xpath("//input[@id='meta_title']")).sendKeys("New Prod details");
		//driver.findElement(By.xpath("//*[@id='page-wrapper']/div/form/div[1]/button")).click();
		
		admin.clickonDataAddNew();
		
		driver.findElement(By.xpath("//input[@id='model']")).sendKeys("1098");
		driver.findElement(By.xpath("//input[@id='price']")).sendKeys("1890");
		driver.findElement(By.xpath("//input[@id='special_dis']")).sendKeys("0");
		//driver.findElement(By.xpath("//input[@id='price_after_special_dis']")).sendKeys("1890");
		
		admin.clickonLinkAddNew();
		Thread.sleep(3000);
		WebElement tabEle= driver.findElement(By.xpath("//*[@id='tabs']"));
		Select select=new Select(tabEle);
		select.selectByValue("92");
		
		
		WebElement catagoryEle= driver.findElement(By.xpath("//select[@id='categories']"));
		Select select1=new Select(catagoryEle);
		select1.selectByVisibleText("Grains");
		
		admin.clickonImageAddNew();
		driver.findElement(By.xpath("//*[@id='tab4']/div/div/span")).click();
		//Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='tab4']/div/div/span")).sendKeys("Pictures\\Saved Pictures\\download.jpg");
		
		driver.findElement(By.xpath("//button[@title='Save']")).click();
		WebElement message = driver.findElement(By.xpath("//*[@id='page-wrapper']/div/div[2]"));
				
		assertTrue("Success: You have successfully added product!", message.getText().contains("Success: You have successfully added product!"));
		WebElement actualPrice= driver.findElement(By.xpath("//*[@id='dataTableExample2']/tbody/tr[1]/td[5]"));
		String msg1 = actualPrice.getText().trim();
		 System.out.println(msg1);
		driver.navigate().to("https://atozgroceries.com/");
		driver.findElement(By.xpath("//input[@id='search-box']")).click();
		driver.findElement(By.xpath("//*[@id='searchModal']/div/div/div/div[1]/input")).sendKeys("New Prod Req");
		driver.findElement(By.xpath("//*[@id='searchproducts-div']/a/span")).click();
		
		WebElement expectedprice = driver.findElement(By.xpath("//*[@id='mm-0']/div[5]/div/div[2]/div/div/div[2]/div/p[1]/span"));
		 String msg =  expectedprice.getText().trim();
		 System.out.println(msg);
	 assertEquals(msg1, msg, "the price on both pages is same");
	 }
}
	/*@Test
	public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		
		String url = data.get("url");
		String userName = data.get("User1");
		String phonenumber = data.get("phonenumb");
		String password = data.get("Userpassword");
		String ConfirmPaswrd = data.get("ConfirmPassword");
		driver.get(url);
		UserPage userpageEle = new UserPage(driver, wait);
		userpageEle.clickonSignUpButn();
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		userpageEle.enterUserName(userName);
		userpageEle.enterUserPhoneNumber(phonenumber);
		userpageEle.enterUserpassword(password);
		userpageEle.enterUserConfirmPass(ConfirmPaswrd);
		userpageEle.clickOnTickBtn();
		userpageEle.clickOnUserSignUpButton();
		//Thread.sleep(5000);
		userpageEle.clickOnPromptbox();
		
		
		//userpageEle.clickOnUserMyAccount();
		//userpageEle.clickOnUserSignOutButton();
		
	@AfterTest
	public void Adminlogin() throws FileNotFoundException, IOException, InterruptedException
	{
		driver.navigate().to("https://atozgroceries.com/admin");
		Thread.sleep(5000);
		String userName1 = data.get("user");
		String password1 = data.get("password");
		
		
		Login loginele = new Login(driver, wait);
		loginele.enterEmailAddress(userName1);
		loginele.enterPassword(password1);
		loginele.clickOnLogin();
		Properties p1 = new Properties();
		p1.load(new FileInputStream("TestData/data.properties"));
		
		AdminPage admin = new AdminPage(driver);
		admin.clickonCustomerab();
		
		String pageSource = driver.getPageSource();
		if(pageSource.contains("Sweety Agarwal"))
		{
			System.out.println("Customer User name is created on user page");
		}
	 }
	}
	*/
	
/*	@Test
	public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		
		String url = data.get("url");
		String userName = data.get("user");
		String password = data.get("password");
		driver.get(url);
		
		Login loginele = new Login(driver, wait);
		loginele.enterEmailAddress(userName);
		loginele.enterPassword(password);
		loginele.clickOnLogin();
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		
		AdminPage admin = new AdminPage(driver);
		admin.clickonSystemtab();
		admin.clickonsettingstab();
		
		String pageSource = driver.getPageSource();
		if(pageSource.contains("Opening Times"))
		{
			System.out.println("Opening Times is present on page");
		}
		WebElement openingTimelink = driver.findElement(By.xpath("//*[@id='openingtimes']"));
		System.out.println(openingTimelink.getText());
		String oldMessage= openingTimelink.getText();
		
		 driver.findElement(By.xpath("//*[@id='openingtimes']")).sendKeys("new message added");
		 
		WebElement saveEle= driver.findElement(By.xpath("//button[@title='Save']"));
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",saveEle ); 
		
		WebElement validationmsg = driver.findElement(By.xpath("//*[@id='page-wrapper']/div/div[2]"));
		System.out.println(validationmsg.getText());
		
		for(int i=1;i<=10;i++)
		{
			js.executeScript("window.scrollBy(0,200);");
		}
		
		WebElement msgadded= driver.findElement(By.xpath("//*[@id='openingtimes']"));
		System.out.println(msgadded.getText());
		String newMessage= msgadded.getText();
	
		
		assertNotEquals(oldMessage , newMessage);
		
		loginele.clickOnLogout();
		}
	}*/

	/*@Test
	public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		
		String url = data.get("url");
		String userName = data.get("user");
		String password = data.get("password");
		driver.get(url);

		Login loginele = new Login(driver, wait);
		loginele.enterEmailAddress(userName);
		loginele.enterPassword(password);
		loginele.clickOnLogin();
		Thread.sleep(5000);
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		
		AdminPage admin = new AdminPage(driver);
		admin.clickonSystemtab();
		admin.clickonWeightClasstab();
		//Thread.sleep(5000);
		List<WebElement>rows= driver.findElements(By.xpath("//*[@class='table table-bordered table-striped table-hover dataTable no-footer']/tbody/tr"));
		int noOfRows=rows.size();
		System.out.println("Total number of rows in a weight class tab is:"+ noOfRows);
	
		List<WebElement>cols= driver.findElements(By.xpath("//*[@class='table table-bordered table-striped table-hover dataTable no-footer']/tbody/tr[1]/td"));
		int noOfCols=cols.size();
		System.out.println("Total number of columns in a weight class tab is:"+ noOfCols);
		
		WebElement weightclasslink =driver.findElement(By.xpath("//*[@class='table table-bordered table-striped table-hover dataTable no-footer']/tbody/tr[4]"));
		System.out.println(weightclasslink.getText());
		
		driver.findElement(By.xpath("//*[@id='dataTableExample2']/tbody/tr[4]/td[5]/div/button")).click();
		
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='dataTableExample2']/tbody/tr[4]/td[5]/div/ul/li[2]/a")).click();
		
		Thread.sleep(2000);

		WebElement alertBoxEle1 = driver.findElement(By.className("confirm"));
		alertBoxEle1.click();
		Thread.sleep(2000);
		String pageSource = driver.getPageSource();
		if(pageSource.contains(" You have successfully deleted data!"))
		{
			System.out.println("Data is deleted successfully");
		}
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='page-wrapper']/div/div[3]")).isDisplayed());
		System.out.println("Data is deleted successfully");
		
		loginele.clickOnLogout();
		}
	}*/
	/*
	@Test
	public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		
		String url = data.get("url");
		String userName = data.get("user");
		String password = data.get("password");
		driver.get(url);

		Login loginele = new Login(driver, wait);
		loginele.enterEmailAddress(userName);
		loginele.enterPassword(password);
		loginele.clickOnLogin();
		Thread.sleep(5000);
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		
		AdminPage admin = new AdminPage(driver);
		
		admin.clickonMarketingtab();
		admin.clickonMailtab();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[@title='Add New']")).click();
		
		Select select=new Select(driver.findElement(By.name("from")));
		
		select.selectByVisibleText("Default");
		
        Select select1=new Select(driver.findElement(By.name("to")));
		
		select1.selectByVisibleText("All Customers");
		driver.findElement(By.id("email")).sendKeys(p.getProperty("email_cust"));
		driver.findElement(By.name("subject")).sendKeys("new-mail-draft");
		driver.findElement(By.xpath("//*[@class='note-editable panel-body']")).sendKeys("this is a new mail drafted.");
		Thread.sleep(5000);
		
		//driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/div[1]/button")).click();
		driver.findElement(By.xpath("//button[@type='Submit']")).click();
		Thread.sleep(5000);
		loginele.clickOnLogout();
	
	 }
}*/
	
/*	@Test
	public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		driver.get(p.getProperty("url"));
		driver.findElement(By.name("email")).sendKeys(p.getProperty("user"));
		driver.findElement(By.name("pword")).sendKeys(p.getProperty("password"));
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/form/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='side-menu']/li[7]/a/span")).click();
		driver.findElement(By.xpath("//*[@id='side-menu']/li[7]/ul/li[1]/a")).click();
		driver.findElement(By.className("form-control")).click();
		
		Select select=new Select(driver.findElement(By.className("form-control")));
		select.selectByVisibleText("Customers Report");
		String title = driver.getTitle();
		System.out.println("Title of th page: "+title);
		if(title.contains("Customers"))
		{
			System.out.println("Test case passed!!");
		}
		else
		{
			System.out.println("Test case failed!!");
		}
		
      String pageSource = driver.getPageSource();
		if(pageSource.contains(" Customer List"))
		{
			System.out.println("Search is correct");
		}
		
	 
	driver.findElement(By.partialLinkText("Logout")).click();
	driver.quit();
	 }
 }*/

	/*public void login() throws FileNotFoundException, IOException, InterruptedException
	 {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		driver.get(p.getProperty("url"));
		driver.findElement(By.name("email")).sendKeys(p.getProperty("user"));
		driver.findElement(By.name("pword")).sendKeys(p.getProperty("password"));
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/form/button")).click();
		
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"side-menu\"]/li[2]/a/span")).click();
		
		Thread.sleep(5000);
		driver.findElement(By.partialLinkText("Products")).click();
		
		Select select=new Select(driver.findElement(By.name("dataTableExample2_length")));
		select.selectByValue("50");
		
		List<WebElement>rows= driver.findElements(By.xpath("//*[@id='dataTableExample2']/tbody/tr"));
		int noOfRows=rows.size();
		System.out.println(noOfRows);
		
		
			for (int i=1; i<=noOfRows; i++)
				
			{
				
				List<WebElement>cols= driver.findElements(By.xpath("//*[@id='dataTableExample2']/tbody/tr["+i+"]/td"));
				int noOfcols=cols.size();
				System.out.println(noOfcols);
				{
				for (int j=1; j<=noOfcols; j++)
				{
				WebElement productlink =driver.findElement(By.xpath("//*[@id='dataTableExample2']/tbody/tr["+i+"]/td["+j+"]"));
					
				System.out.println(productlink.getText());
				}
			}
			}
		//Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"dataTableExample2_paginate\"]/ul/li[2]/a\r\n")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"dataTableExample2_next\"]/a")).isDisplayed());
		driver.findElement(By.xpath("//*[@id=\"dataTableExample2_next\"]/a")).click();
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"dataTableExample2_previous\"]/a")).isDisplayed());
		driver.findElement(By.xpath("//*[@id=\"dataTableExample2_previous\"]/a")).click();
		
				
		driver.findElement(By.partialLinkText("Logout")).click();
		driver.quit();
		
	 }*/

	/*public void testcase1()throws IOException
	{
		String file="./TestData/magentodata.properties";
		
		
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data= propFileHandler.getPropertiesAsMap(file);
	}
	
	//excel data using dataprovider
	//run and check	
	//sends data in excel one by one
    @Test(dataProvider = "data")
    public void testcase2(String user, String pwd){
    		System.out.println(user);
    		System.out.println(pwd);
    }

    @DataProvider(name="data")
    public Object[][] data() throws IOException {
        return ExcelUtil.DataTable("./TestData/TestData.xlsx","LoginData");
    }
}*/

